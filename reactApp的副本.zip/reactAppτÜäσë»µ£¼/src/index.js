import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, IndexRoute, hashHistory } from 'react-router';

/* 引入路由文件 */
import App from './App';
// 注册
import SignIn from './routers/SignIn';
// 登陆
import LogIn from './routers/LogIn';
// 主页
import Home from './routers/Home';
import Index from './routers/Home/IndexPage';
import WorkOrder from './routers/Home/WorkOrder';
import Team from './routers/Home/Team';
import ImportPlan from './routers/Home/Team/ImportPlan';
import ManageOrg from './routers/Home/Team/ManageOrg';
import SyncFromDingding from './routers/Home/Team/SyncFromDingding';
import ManagePeople from './routers/Home/Team/ManagePeople';
import ManageCharactor from './routers/Home/Team/ManageCharactor';
import AllCancelledPeople from './routers/Home/Team/AllCancelledPeople';
import SuperManager from './routers/Home/Team/SuperManager';
import MagageAgency from './routers/Home/Team/MagageAgency';
import ManageArea from './routers/Home/Team/ManageArea';
import AllCancelledAgency from './routers/Home/Team/AllCancelledAgency';
// 考核
import Check from './routers/Home/Check';
// 质检
import QualityTesting from './routers/Home/QualityTesting';
// 报表
import ReportForms from './routers/Home/ReportForms';
// 更多
import More from './routers/Home/More';
// 设置
import Setting from './routers/Home/Setting';

import './index.css';

ReactDOM.render(
  <Router history={hashHistory}>
    <Route path="/" component={App}>
      <IndexRoute component={LogIn} />
      // 注册
      <Route path="/sign-in" component={SignIn} />
      // 登陆
      <Route path="/log-in" component={LogIn} />
      // 主页
      <Route path="/home" component={Home}>
        <IndexRoute component={Index} />
        // 首页
        <Route path="/home/index" component={Index} />
        // 工单
        <Route path="/home/workorder" component={WorkOrder} />
        // 团队
        <Route path="/home/team" component={Team}>
          // 引入一个方案
          <Route path="/home/team/importplan" component={ImportPlan} />
          // 管理组织
          <Route path="/home/team/manageorg" component={ManageOrg} />
          // 从钉钉同步
          <Route path="/home/team/syncfromdingding" component={SyncFromDingding} />
          // 管理人员
          <Route path="/home/team/managepeople" component={ManagePeople} />
          // 管理角色
          <Route path="/home/team/managecharactor" component={ManageCharactor} />
          // 所有作废人员
          <Route path="/home/team/allcancelledpeople" component={AllCancelledPeople} />
          // 超级管理员
          <Route path="/home/team/supermanager" component={SuperManager} />
          // 管理代理商
          <Route path="/home/team/magageagency" component={MagageAgency} />
          // 管理地域/区域
          <Route path="/home/team/managearea" component={ManageArea} />
          // 所有作废代理商
          <Route path="/home/team/allcancelledagency" component={AllCancelledAgency} />
        </Route>
        // 考核
        <Route path="/home/check" component={Check} />
        // 质控
        <Route path="/home/qualitytesting" component={QualityTesting} />
        // 报表
        <Route path="/home/reportforms" component={ReportForms} />
        // 更多
        <Route path="/home/more" component={More} />
        // 设置
        <Route path="/home/setting" component={Setting} />
      </Route>
    </Route>
  </Router>,
  document.getElementById('root')
);
