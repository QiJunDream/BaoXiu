import React, { Component } from 'react';
import { Form } from 'react-bootstrap';
import { FormGroup, Col, FormControl, ControlLabel } from 'react-bootstrap';

export default class extends Component {
  render() {
    return (
      <div className='container'>
        <Form horizontal className='center-block'>
          <FormGroup controlId="formHorizontalEmail">
            <Col componentClass={ControlLabel} sm={2}>企业名称</Col>
            <Col sm={10}>
              <FormControl type="email" placeholder="请填写您的企业名称" />
            </Col>
          </FormGroup>
        </Form>
      </div>
    );
  }
}
