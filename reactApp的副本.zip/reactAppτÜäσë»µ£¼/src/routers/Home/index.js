import React, { Component } from 'react';
import NavLink from './NavLink';
import { Navbar, FormGroup, FormControl, Button, ListGroup, ListGroupItem, Col } from 'react-bootstrap';

export default class extends Component {

  render() {
    return (
      <div className='container'>
        <Col xs={3}>
          <ListGroup>
            <ListGroupItem>闪电豹</ListGroupItem>
            <ListGroupItem><NavLink to="/home/index" className='display-block'>首页</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/workorder" className='display-block'>工单</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/team">团队</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/check">考核</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/qualitytesting">质检</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/reportforms">报表</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/more">更多</NavLink></ListGroupItem>
            <ListGroupItem><NavLink to="/home/setting">设置</NavLink></ListGroupItem>
          </ListGroup>
        </Col>
        <Col xs={9}>
          <Navbar>
            <Navbar.Header>
              <Navbar.Toggle />
            </Navbar.Header>
            <Navbar.Collapse>
              <Navbar.Form pullLeft>
                <FormGroup>
                  <FormControl type="text" placeholder="Search" />
                </FormGroup>
                {' '}
                <Button type="submit">Submit</Button>
              </Navbar.Form>
            </Navbar.Collapse>
          </Navbar>
          <div>
            {this.props.children}
          </div>
        </Col>
      </div>
    );
  }
}
