import React, { Component } from 'react';
import { Col } from 'react-bootstrap';
import NavLink from './NavLink';

export default class extends Component {
  render() {
    return (
      <div className='container'>
        <Col xs={3}>
          <dl>
            <dt>组织（部门）管理</dt>
            <dd><NavLink to="/home/team/importplan" className='display-block'>引入一个方案</NavLink></dd>
            <dd><NavLink to="/home/team/manageorg" className='display-block'>管理组织</NavLink></dd>
            <dd><NavLink to="/home/team/syncfromdingding" className='display-block'>从钉钉同步</NavLink></dd>
          </dl>
          <dl>
            <dt>人员管理</dt>
            <dd><NavLink to="/home/team/managepeople" className='display-block'>管理人员</NavLink></dd>
            <dd><NavLink to="/home/team/managecharactor" className='display-block'>管理角色</NavLink></dd>
            <dd><NavLink to="/home/team/allcancelledpeople" className='display-block'>所有作废人员</NavLink></dd>
            <dd><NavLink to="/home/team/supermanager" className='display-block'>超级管理员</NavLink></dd>
          </dl>
          <dl>
            <dt>代理商管理</dt>
            <dd><NavLink to="/home/team/magageagency" className='display-block'>管理代理商</NavLink></dd>
            <dd><NavLink to="/home/team/managearea" className='display-block'>管理地域/区域</NavLink></dd>
            <dd><NavLink to="/home/team/allcancelledagency" className='display-block'>所有作废代理商</NavLink></dd>
          </dl>
        </Col>
        <Col xs={9}>
          {this.props.children}
        </Col>
      </div>
    );
  }
}
