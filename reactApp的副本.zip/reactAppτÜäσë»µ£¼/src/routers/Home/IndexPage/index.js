import React, { Component } from 'react';
import $ from 'jquery';

export default class extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: 0
    };
  }


  componentWillMount() {
    $.ajax({
      url: 'http://127.0.0.1:3001',
      dataType: 'json',
      success: function (json) {
        console.log('success++++++++++++++', json);
      },
      error: function (err) {
        console.log('error++++++++++++++', err);
      }
    });
  }

  render() {
    return (
      <div>
        {this.state.value}
      </div>
    );
  }
}
